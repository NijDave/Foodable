<!DOCTYPE html>
<?php
session_start();
include '../connection.php'; 
$charity_id=$_SESSION['userid'];
$select_query="select * from charity_master where id=$charity_id";
$exe_query = mysqli_query($connection, $select_query);

$nums = mysqli_num_rows($exe_query);

while ($res = mysqli_fetch_array($exe_query)) 
{
    $user_name=$res['name'];
    $user_email=$res['email'];
    $user_password=$res['password'];
    $user_address=$res['address'];
    $user_city=$res['city'];
    $user_state=$res['state'];
} 
    if (isset($_POST['update_details']))
    {   
        $name=$_POST["name"];
        $email=$_POST["email"];
        $addr=$_POST["addr"];
        $password=$_POST["password"];
        $city=$_POST["city"];
        $state=$_POST["state"];

        $sql="update charity_master set name='$name',email='$email',password='$password',city='$city',state='$state'";
        if(mysqli_query($connection,$sql))
        {
            header("Location:charity_home.php");
            exit();
        }
        else
        {
            echo "Error".$sql."<br>".mysqli_error($conn);
        }
        mysqli_close($conn);
    }
?>
<html>
  <body>
    <h1>Signup</h1>
    <form method="POST" action="">
    <img src="../ProfileImages/user.png"/></br>
      <label for="name">Name:</label>
      <input type="text"  name="name" value="<?php echo $user_name;?>" required><br>

      <label for="email">Email:</label>
      <input type="email"  name="email" value="<?php echo $user_email;?>" required><br>

      <label for="password">Password:</label>
      <input type="text"  name="password" value="<?php echo $user_password;?>" required><br>

      <label for="Address">Address:</label>
      <input type="text"  name="addr" value="<?php echo $user_address;?>" required><br>

      <label for="City">City:</label>
      <input type="text"  name="city" value="<?php echo $user_city;?>" required><br>

      <label for="State">State:</label>
      <input type="text"  name="state" value="<?php echo $user_state;?>" required><br>
        
      <input type="submit" name="update_details" value="Update Details"/>
    </form>
</body>
</html>