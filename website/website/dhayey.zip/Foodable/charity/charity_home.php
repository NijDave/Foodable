<?php
 session_start(); 
?>
<html>
    <body>
        <a href="viewcontributor.php"><input type="button" value="Contributor Details"/></a>
        <a href="charityGiveRequest.php"><input type="button" value="Give Request"/></a>
        <a href="charityPendingRequest.php"><input type="button" value="Pending Request"/></a>
        <a href="charityAcceptedRequest.php"><input type="button" value="Accepted Request"/></a>
        <a href="charityProfilePage.php"><input type="button" value="Profile Page"/></a>
        <a href="charityLikedContributor.php"><input type="button" value="Likes"/></a>
        <a href="../logout.php"><input type="button" value="Log Out"/></a>
</body>
</html>