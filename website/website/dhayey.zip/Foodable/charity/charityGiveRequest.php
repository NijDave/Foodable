<!DOCTYPE html>

<html>
  <body>
    <h1>DATA BASE DETAILS</h1>
    <div class="table-responsive">
        <table border="1">
            <thead>
                <tr>
                    <th>id</th>
                    <th>name</th>
                    <th>Email</th>
                    <th>address</th>
                    <th>City</th>
                    <th>State</th>
                    <th>Requests</th>
                </tr>
            </thead>
            <tbody>
            <?php
                    include '../connection.php';
                    $selectquery= "select * from contributor_master";

                    $query= mysqli_query($connection,$selectquery);

                    $nums=mysqli_num_rows($query);

                    while($res=mysqli_fetch_array($query)){
                        ?>
                        <tr>
                        <td><?php echo $res['id'] ?></td>
                        <td><?php echo $res['name']?></td>
                        <td>
                            <?php echo $res['email'] ?>
                        </td>
                        <td>
                            <span=class="email-style">
                                <?php echo $res['address'] ?></span>
                        </td>
                        <td>
                            <?php echo $res['city'] ?>
                        </td>
                        <td>
                            <?php echo $res['state'] ?>
                        </td>
                        <td>
                        <a href="request.php?contributor_id=<?php echo $res['id'];?>">Request</a>
                            </td>
                    </tr>
                        <?php
                    }
                    ?>


                
            </tbody>
        </table>
    
</body>
</html>