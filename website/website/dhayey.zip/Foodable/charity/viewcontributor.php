<!DOCTYPE html>
<?php
include '../connection.php';
$selectquery = "select * from contributor_master";
#$selectquery="SELECT contributor_master.id,contributor_master.name,contributor_master.address,contributor_master.email,contributor_master.password,count(*) as rowcount from contributor_master INNER JOIN charity_like on contributor_master.id=charity_like.contributor_id where contributor_master.id=4";
$query = mysqli_query($connection, $selectquery);

$nums = mysqli_num_rows($query);
$grouparr=[];
while($res=mysqli_fetch_array($query))
{
    $arr=[];
    $arr[]=$res['id'];
    $arr[]=$res['name'];
    $arr[]=$res['email'];
    $arr[]=$res['address'];
    $arr[]=$res['city'];
    $arr[]=$res['state'];
    $grouparr[]=$arr;
}
$selectquery1 = "SELECT contributor_id,count(*)as count FROM charity_like group by contributor_id order by contributor_id;";
$query1 = mysqli_query($connection, $selectquery1);

$nums = mysqli_num_rows($query1);
while($res=mysqli_fetch_array($query1))
{
    for($i=0;$i<count($grouparr);$i++)
    {
        if($grouparr[$i][0]==$res['contributor_id'])
        {
            $grouparr[$i][]=$res['count'];
            break;
        }
    }
}
for($i=0;$i<count($grouparr);$i++)
{
    if(count($grouparr[$i])==6)
    {
        $grouparr[$i][]=0;
    }
}
?>
<html>

<body>
    <h1>DATA BASE DETAILS</h1>
    <div class="table-responsive">
        <table border="1">
            <thead>
                <tr>
                    <th>id</th>
                    <th>name</th>
                    <th>Email</th>
                    <th>address</th>
                    <th>City</th>
                    <th>State</th>
                    <th>like</th>
                    <th>no_of_like</th>
                </tr>
            </thead>
            <tbody>
                <?php
                for($i=0;$i<count($grouparr);$i++)
                {
                    $k=0;
                    ?>
                <tr>
                    <td>
                        <?php echo  $grouparr[$i][0];?>
                    </td>
                    <td>
                    <?php echo  $grouparr[$i][1];?>
                    </td>
                    <td>
                    <?php echo  $grouparr[$i][2];?>
                    </td>
                    <td>
                        <span=class="email-style">
                        <?php echo  $grouparr[$i][3];?>
                    </td>
                    <td>
                    <?php echo  $grouparr[$i][4];?>
                    </td>
                    <td>
                    <?php echo  $grouparr[$i][5];?>
                    </td>
                    <td>
                        <a href="likePage.php?contibutor_id=<?php echo  $grouparr[$i][0];?>">like</a>
                    </td>
                    <td>
                    <?php try { echo  $grouparr[$i][6];}catch(Exception $ex){echo 0;} ?>
                    </td>
                </tr>
                    <?php
                }
                ?>



            </tbody>
        </table>
</body>

</html>