<!DOCTYPE html>

<html>
  <body>
    <h1>Accepted Request</h1>
    <div class="table-responsive">
        <table border="1">
            <thead>
                <tr>
                    <th>id</th>
                    <th>name</th>
                    <th>Email</th>
                    <th>address</th>
                    <th>City</th>
                    <th>State</th>
                    <th>Chat</th>
                </tr>
            </thead>
            <tbody>
            <?php
                     session_start();
                     include "../connection.php";
                     $contributor_id=$_SESSION['userid'];
                     $selectquery= "select * from charity_master inner join charity_request_contributor on charity_master.id=charity_request_contributor.charity_id where charity_request_contributor.request_status=1 and charity_request_contributor.contributor_id=$contributor_id";

                     $query= mysqli_query($connection,$selectquery);

                     $nums=mysqli_num_rows($query);

                     while($res=mysqli_fetch_array($query)){
                        ?>
                        <tr>
                        <td><?php echo $res['id'] ?></td>
                        <td><?php echo $res['name']?></td>
                        <td>
                            <?php echo $res['email'] ?>
                        </td>
                        <td>
                            <span=class="email-style">
                                <?php echo $res['address'] ?></span>
                        </td>
                        <td>
                            <?php echo $res['city'] ?>
                        </td>
                        <td>
                            <?php echo $res['state'] ?>
                        </td>
                        <td>
                            <a href="startChatprocess.php?charity_id=<?php echo $res['id'] ?>">chat</a>
                        </td>
                     </tr>
                        <?php
                    }
                    ?>


                
            </tbody>
        </table>
    
</body>
</html>