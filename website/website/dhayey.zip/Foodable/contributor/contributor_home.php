<?php
 session_start(); 
?>
<html>
       <body>
       <a href="viewcharity.php"><input type="button" value="Charity Details"/></a>
       <a href="contributorPendingRequest.php"><input type="button" value="Pending Request"/></a>
       <a href="contributorAcceptedRequest.php"><input type="button" value="Accepted Request"/></a>
       <a href="contributorProfilePage.php"><input type="button" value="Profile Page"/></a>
       <a href="../logout.php"><input type="button" value="Log Out"/></a>
</body>
</html>