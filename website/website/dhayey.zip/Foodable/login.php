<!DOCTYPE html>
<?php     
    session_start(); 
    include 'connection.php';  

    if (isset($_POST['submit'])){

        $email = $_POST['email'];  
        $passw = $_POST['password'];  
        $user=$_POST["user"];
        $email = stripcslashes($email);  
        $passw = stripcslashes($passw);  //to remove the backslashes from email 
        $email = mysqli_real_escape_string($connection, $email);  
        $passw = mysqli_real_escape_string($connection, $passw); // to escape sprcial character in email to prevent sql injection
        if($user=="CHARITY")
        {
            $query = "select * from charity_master where email = '$email' and password = '$passw'";  
            $execute = mysqli_query($connection, $query);  
            $row = mysqli_fetch_array($execute, MYSQLI_ASSOC);  
            $no_rows = mysqli_num_rows($execute);  
            
            if($no_rows == 1){  
                $result=$connection->query($query);
                while($row=$result->fetch_assoc())
                {
                    $id= $row["id"];
                }
                $_SESSION['userid']=$id;
                $query = "select * from users where usertype='charity' and user_type_id=$id";  
                $execute = mysqli_query($connection, $query);  
                $row = mysqli_fetch_array($execute, MYSQLI_ASSOC);  
                $no_rows = mysqli_num_rows($execute);
                if($no_rows == 1){  
                    $result=$connection->query($query);
                    while($row=$result->fetch_assoc())
                    {
                        $uniq_id= $row["unique_id"];
                        $user_id=$row['user_id'];
                    }
                    $_SESSION['unique_id']=$uniq_id;
                }
                header("Location:charity/charity_home.php");
                exit();
            }  
            else{  
                echo "<center> <h1 > Login failed. Invalid email or password.</center></h1>";
            }
        }
        else
        {
            $query = "select * from contributor_master where email = '$email' and password = '$passw'";  
            $execute = mysqli_query($connection, $query);  
            $row = mysqli_fetch_array($execute, MYSQLI_ASSOC);  
            $no_rows = mysqli_num_rows($execute);  
            
            if($no_rows == 1){  
                $result=$connection->query($query);
                while($row=$result->fetch_assoc())
                {
                    $id= $row["id"];
                }
                $_SESSION['userid']=$id;
                $query = "select * from users where usertype='contributor' and user_type_id=$id";  
                $execute = mysqli_query($connection, $query);  
                $row = mysqli_fetch_array($execute, MYSQLI_ASSOC);  
                $no_rows = mysqli_num_rows($execute);
                if($no_rows == 1){  
                    $result=$connection->query($query);
                    while($row=$result->fetch_assoc())
                    {
                        $uniq_id= $row["unique_id"];
                        $user_id=$row['user_id'];
                    }
                    $_SESSION['unique_id']=$uniq_id;
                }
                header("Location:contributor/contributor_home.php");
                exit();
            }  
            else{  
                echo "<center> <h1 > Login failed. Invalid username or password.</center></h1>";
            }
        }
    }
     
?> 

<html lang="en">
  <body>
    <form method="post" >
        <h2>Admin Login</h2>
        <input
        type="text"
        placeholder="User Id "
        name="email"
        required
        />

          <input
            type="password"
            placeholder="Enter password "
            name="password"
            required
          />

          Login as:      
      <input type="Radio"  value="CHARITY" name="user"/>CHARITY
      <input type="Radio"  value="CONTRIBUTOR" name="user"/>CONTRIBUTOR</br>
          <button type="submit" name="submit">
           LOGIN 
          </button>
          <a href="SignUp.php">Sign up</a>
    </form>
  </body>
</html>