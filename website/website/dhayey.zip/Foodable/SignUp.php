<!DOCTYPE html>
<?php
include 'connection.php';  
    if (isset($_POST['submit']))
    {   
        $name=$_POST["name"];
        $email=$_POST["email"];
        $addr=$_POST["addr"];
        $password=$_POST["password"];
        $city=$_POST["city"];
        $state=$_POST["state"];
        $user=$_POST["user"];
        
        if($user=="CHARITY")
        {
            $sql="INSERT INTO charity_master(name,email,password,address,city,state) VALUES ('$name','$email','$password','$addr','$city','$state')";
            if(mysqli_query($connection,$sql))
            {
                $id=$connection->insert_id;
                $query = "select * from users where usertype='charity' and user_type_id=$id ";
                $execute = mysqli_query($connection, $query);  
                $row = mysqli_fetch_array($execute, MYSQLI_ASSOC);  
                $no_rows = mysqli_num_rows($execute);  

                if($no_rows >0){  
                    header("Location:login.php");
                    exit();
                } 
                else
                {
                    $ran_id = rand(time(), 100000000);
                    $insert_query="insert into users(unique_id, name, email,status,usertype,user_type_id) value($ran_id,'$name','$email','Active now','charity',$id)";
                    mysqli_query($connection,$insert_query);
                    header("Location:login.php");
                    exit();
                } 
            }
            else
            {
                echo "Error".$sql."<br>".mysqli_error($conn);
            }
        }
        else
        {
            $sql="INSERT INTO contributor_master(name,email,password,address,city,state) VALUES ('$name','$email','$password','$addr','$city','$state')";
            if(mysqli_query($connection,$sql))
            {
                $id=$connection->insert_id;
                $query = "select * from users where usertype='contributor' and user_type_id=$id ";
                $execute = mysqli_query($connection, $query);  
                $row = mysqli_fetch_array($execute, MYSQLI_ASSOC);  
                $no_rows = mysqli_num_rows($execute);  

                if($no_rows >0){  
                    header("Location:login.php");
                    exit();
                } 
                else
                {
                    $ran_id = rand(time(), 100000000);
                    $insert_query="insert into users(unique_id, name, email,status,usertype,user_type_id) value($ran_id,'$name','$email','Active now','contributor',$id)";
                    mysqli_query($connection,$insert_query);
                    header("Location:login.php");
                    exit();
                }
            }
            else
            {
                echo "Error".$sql."<br>".mysqli_error($conn);
            }
        }
        mysqli_close($conn);
    }
?>
<html>
  <body>
    <h1>Signup</h1>
    <form method="POST" action="">
      <label for="name">Name:</label>
      <input type="text"  name="name" required><br>

      <label for="email">Email:</label>
      <input type="email"  name="email" required><br>

      <label for="password">Password:</label>
      <input type="password"  name="password" required><br>

      <label for="Address">Address:</label>
      <input type="text"  name="addr" required><br>

      <label for="City">City:</label>
      <input type="text"  name="city" required><br>

      <label for="State">State:</label>
      <input type="text"  name="state" required><br>

      Register as:      
      <input type="Radio"  value="CHARITY" name="user"/>CHARITY
      <input type="Radio"  value="CONTRIBUTOR" name="user"/>CONTRIBUTOR</br>
      <input type="submit" name="submit"/>
      <a href="login.php">exisiting user </a>
    </form>
</body>
</html>